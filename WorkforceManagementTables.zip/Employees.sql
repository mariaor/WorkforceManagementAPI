USE [EmployeeManagement]
GO

/****** Object:  Table [dbo].[Employees]    Script Date: 28/2/2019 6:13:12 μμ ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Employees](
	[EmployeeID] [int] NOT NULL,
	[EmployeeTitle] [nvarchar](5) NOT NULL,
	[EmployeeFirstName] [nvarchar](50) NOT NULL,
	[EmployeeSurname] [nvarchar](50) NOT NULL,
	[EmployeeSocialSecurityNumber] [nvarchar](250) NOT NULL,
	[EmployeeAddress] [nvarchar](250) NULL,
	[EmployeePhone] [nvarchar](50) NULL,
	[EmployeeHireDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

