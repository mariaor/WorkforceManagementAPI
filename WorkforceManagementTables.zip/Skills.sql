USE [EmployeeManagement]
GO

/****** Object:  Table [dbo].[Skills]    Script Date: 28/2/2019 6:13:36 μμ ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Skills](
	[SkillID] [int] NOT NULL,
	[SkillName] [nvarchar](100) NOT NULL,
	[SkillDescription] [nvarchar](500) NOT NULL,
	[SkillDateOfCreation] [datetime] NOT NULL,
 CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED 
(
	[SkillID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

